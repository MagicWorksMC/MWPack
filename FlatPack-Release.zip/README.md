# MWPack
Considered the main/primary resource pack for MagicWorksMC
